const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle?.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});

navLinks?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
    if (menuToggle) menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

// Course links preselect the relevant course in the enquiry form.
document.querySelectorAll("[data-course]").forEach((link) => {
  link.addEventListener("click", () => {
    const course = document.getElementById("course");
    if (course) course.value = link.dataset.course;
  });
});

// This starter version sends the enquiry using the visitor's email app.
// Connect a backend later for actual online form submission and saved student accounts.
const enrollForm = document.getElementById("enrollForm");
enrollForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(enrollForm);
  const values = Object.fromEntries(formData.entries());
  const subject = encodeURIComponent(`EL-VORA course enquiry — ${values.fullName}`);
  const body = encodeURIComponent(
`Hello EL-VORA Academy,

I would like to enquire about classes.

Name: ${values.fullName}
Email: ${values.email}
Phone: ${values.phone || "Not provided"}
Course: ${values.course}
Level: ${values.level}
Preferred teaching language: ${values.medium}

Please share the next steps and available class timings.

Thank you.`
  );
  document.getElementById("formMessage").textContent = "Opening your email app with the enquiry details…";
  window.location.href = `mailto:jeflin2710@gmail.com?subject=${subject}&body=${body}`;
});

// QR generator: enter the final public website URL after publishing.
// The QR library is loaded from a CDN, so an internet connection is needed.
const makeQrButton = document.getElementById("makeQr");
const siteUrlInput = document.getElementById("siteUrl");
const qrContainer = document.getElementById("qrcode");
const qrPlaceholder = document.getElementById("qrPlaceholder");
const downloadQrButton = document.getElementById("downloadQr");

makeQrButton?.addEventListener("click", () => {
  const url = siteUrlInput.value.trim();
  if (!url) {
    siteUrlInput.focus();
    siteUrlInput.setCustomValidity("Enter your published website URL first.");
    siteUrlInput.reportValidity();
    return;
  }
  siteUrlInput.setCustomValidity("");
  try {
    const parsed = new URL(url);
    if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Invalid protocol");
    if (typeof QRCode === "undefined") {
      alert("The QR generator could not load. Check your internet connection and try again.");
      return;
    }
    qrContainer.innerHTML = "";
    new QRCode(qrContainer, {
      text: parsed.href,
      width: 220,
      height: 220,
      colorDark: "#421321",
      colorLight: "#ffffff",
      correctLevel: QRCode.CorrectLevel.H
    });
    qrPlaceholder.hidden = true;
    downloadQrButton.hidden = false;
  } catch {
    siteUrlInput.setCustomValidity("Please enter a valid URL, for example https://your-site.com");
    siteUrlInput.reportValidity();
  }
});

downloadQrButton?.addEventListener("click", () => {
  const canvas = qrContainer.querySelector("canvas");
  const image = qrContainer.querySelector("img");
  const dataUrl = canvas?.toDataURL("image/png") || image?.src;
  if (!dataUrl) return;
  const anchor = document.createElement("a");
  anchor.href = dataUrl;
  anchor.download = "el-vora-academy-website-qr.png";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
});
