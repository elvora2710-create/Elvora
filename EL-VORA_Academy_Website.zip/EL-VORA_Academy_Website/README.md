# EL-VORA Academy Website

A responsive front-end starter website for EL-VORA Academy, using a maroon-and-cream theme.

## What's included
- Responsive landing page with custom SVG book/floral logo mark
- Hindi and English course cards
- Three levels: Beginner, Intermediate, Professional
- Teaching-language explanation (Hindi through Tamil/English; English through Tamil/Hindi)
- Benefits, enquiry form, About section near the bottom
- Contact links for phone, WhatsApp, email, Instagram
- QR code generator: enter the final published website URL to create and download a QR image

## Run locally
1. Extract the ZIP.
2. Open the `el_vora_academy_website` folder.
3. Double-click `index.html` to open it in a browser.

For a smoother development experience, open the folder in VS Code and use the Live Server extension (optional).

## Before publishing
1. Review all copy and contact information.
2. Replace the custom placeholder logo mark with the official logo asset if desired.
3. Publish the site using your preferred hosting service.
4. Open the published website and enter its final `https://...` URL in the QR section.
5. Click **Create QR**, then **Download QR image** to use it on a poster.

## Important limitations
This is a front-end starter site. The enquiry form opens the visitor's email application; it does not save submissions to a database. Student accounts, secure Admin/Teacher roles, attendance records, schedules, progress, and certificate management require a real backend (for example Supabase or Firebase) with authentication and server-side access rules. Do not use this version to store private student records or claim it has secure logins.
The QR generator loads QRCode.js from a CDN and therefore needs an internet connection.
